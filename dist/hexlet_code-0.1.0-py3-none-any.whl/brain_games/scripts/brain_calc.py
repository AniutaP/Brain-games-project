from brain_games.games.game_calc.game_calc_start import calc_start


def main():
    print('Welcome to the Brain Games!')
    calc_start()


if __name__ == '__main__':
    main()
