from brain_games.games.game_prime.game_prime_start import prime_start


def main():
    print('Welcome to the Brain Games!')
    prime_start()


if __name__ == '__main__':
    main()
