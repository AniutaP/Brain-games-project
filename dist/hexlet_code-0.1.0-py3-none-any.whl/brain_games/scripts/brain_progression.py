from brain_games.games.game_progression.game_progression_start import (
    progression_start
)


def main():
    print('Welcome to the Brain Games!')
    progression_start()


if __name__ == '__main__':
    main()
