import prompt
from random import randint


def prime_start():
    name = prompt.string('May I have your name? ')
    print(f'Hello, {name}!'
          f'\nAnswer "yes" if the number is even, otherwise answer "no".')
    i = 1
    while i <= 3:
        a = randint(-100, 100)
        b = randint(-100, 100)
        print(f'''Question: {a} {b}''')
        player_answer_prime = prompt.integer('Your answer: ')
        game_answer_prime = gcd(a, b)
        if player_answer_prime == game_answer_prime:
            print('Correct!')
            i += 1
        else:
            print(f"'{player_answer_prime}' is wrong answer ;(. "
                  f"Correct answer was '{game_answer_prime}'."
                  f"\nLet's try again, {name}!")
            break
    else:
        print(f'Congratulations, {name}!')
