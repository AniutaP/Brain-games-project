### Hexlet tests and linter status:
[![Actions Status](https://github.com/AniutaP/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/AniutaP/python-project-49/actions)


### Maintainability Badges:
[![Maintainability](https://api.codeclimate.com/v1/badges/bfd8a95323577b72dfc1/maintainability)](https://codeclimate.com/github/AniutaP/python-project-49/maintainability)


### Asciinema brain-even:
[![asciicast](https://asciinema.org/a/558348.svg)](https://asciinema.org/a/558348)

### Asciinema brain-calc:
[![asciicast](https://asciinema.org/a/558709.svg)](https://asciinema.org/a/558709)

### Asciinema brain-gcd:
[![asciicast](https://asciinema.org/a/559086.svg)](https://asciinema.org/a/559086)
