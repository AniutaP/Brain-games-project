# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['brain_games',
 'brain_games.games.game_calc',
 'brain_games.games.game_even',
 'brain_games.games.game_gcd',
 'brain_games.games.game_progression',
 'brain_games.scripts']

package_data = \
{'': ['*']}

install_requires = \
['prompt>=0.4.1,<0.5.0']

entry_points = \
{'console_scripts': ['brain-calc = brain_games.scripts.brain_calc:main',
                     'brain-even = brain_games.scripts.brain_even:main',
                     'brain-games = brain_games.scripts.brain_games:main',
                     'brain-gcd = brain_games.scripts.brain_gcd:main',
                     'brain-progression = '
                     'brain_games.scripts.brain_progression:main']}

setup_kwargs = {
    'name': 'hexlet-code',
    'version': '0.1.0',
    'description': '',
    'long_description': '### Hexlet tests and linter status:\n[![Actions Status](https://github.com/AniutaP/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/AniutaP/python-project-49/actions)\n\n\n### Maintainability Badges:\n[![Maintainability](https://api.codeclimate.com/v1/badges/bfd8a95323577b72dfc1/maintainability)](https://codeclimate.com/github/AniutaP/python-project-49/maintainability)\n\n\n### Asciinema brain-even:\n[![asciicast](https://asciinema.org/a/558348.svg)](https://asciinema.org/a/558348)\n\n### Asciinema brain-calc:\n[![asciicast](https://asciinema.org/a/558709.svg)](https://asciinema.org/a/558709)\n\n### Asciinema brain-gcd:\n[![asciicast](https://asciinema.org/a/559086.svg)](https://asciinema.org/a/559086)\n',
    'author': 'anna_petukhova',
    'author_email': 'aniuta.petuhova2013@yandex.ru',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.10,<4.0',
}


setup(**setup_kwargs)
