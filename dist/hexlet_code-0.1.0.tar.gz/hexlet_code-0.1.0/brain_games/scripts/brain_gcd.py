from brain_games.games.game_gcd.game_gcd_start import gcd_start


def main():
    print('Welcome to the Brain Games!')
    gcd_start()


if __name__ == '__main__':
    main()
