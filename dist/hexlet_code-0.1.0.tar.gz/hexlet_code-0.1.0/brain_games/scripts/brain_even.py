#!/usr/bin/env python3
from brain_games.games.game_even.game_even_start import even_start


def main():
    print('Welcome to the Brain Games!')
    even_start()


if __name__ == '__main__':
    main()
